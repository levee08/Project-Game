using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PlayerData 
{

    public string PlayerName;
    public string Dificulty;
    public int PlayerAge;
    public float CompleteionTime;
    public int CustomID;

}
