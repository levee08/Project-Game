namespace Gravitons.UI.Modal
{
    /// <summary>
    /// Base class for all modal content
    /// </summary>
    public class ModalContentBase
    {
        
    }
}